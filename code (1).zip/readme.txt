ETran: Energy-Based Transferability Estimation
--> Please use the ETran.ipynb to reproduce the results. 